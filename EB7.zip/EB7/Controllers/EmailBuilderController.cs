﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EB7.Data;
using EB7.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EB7.Controllers
{
    public class EmailBuilderController : Controller
    {




        private readonly ApplicationDbContext _db;
        public EmailBuilderController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View(_db.EmailsDb.ToList());
        }


        // Create actions
        public IActionResult CreateEmail()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEmail(Email email)
        {
            if (ModelState.IsValid)
            {
                _db.Add(email);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(email);
        }





        // Edit
        // To get and display item to edit
        public async Task<IActionResult> EditEmail(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var emailToEdit = await _db.EmailsDb.FindAsync(id);
            if (emailToEdit == null)
            {
                return NotFound();
            }
            return View(emailToEdit);
        }



        // POST Edit Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEmail(int id, Email email)
        {
            if (id != email.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _db.Update(email);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(email);
        }



    }
}
