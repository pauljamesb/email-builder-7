﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace EB7.Models
{
    public class Email
    {

        public int Id { get; set; }
        public string EmailTitle { get; set; }
        public string EmailBody { get; set; }

    }
}
